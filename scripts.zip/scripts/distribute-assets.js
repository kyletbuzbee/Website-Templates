// scripts/distribute-assets.js
import fs from 'fs-extra'; // You might need to npm install fs-extra if not present, or use standard fs
import path from 'path';
import sharp from 'sharp';
import { glob } from 'glob';
import { fileURLToPath } from 'url';

// Dynamic imports for image analysis
let analyzeImageContent;
let convertPngToSvg;

// Setup paths for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '..');

// Import image analysis utilities
(async () => {
    const imageAnalysis = await import('../src/utils/image-analysis.js');
    analyzeImageContent = imageAnalysis.analyzeImageContent;
    convertPngToSvg = imageAnalysis.convertPngToSvg;
})();

// Configuration
const CONFIG = {
    dropZone: path.join(PROJECT_ROOT, '_raw_assets'), // Create this folder!
    industriesDir: PROJECT_ROOT, // Root directory contains industry folders directly
    // Valid industry names (including hyphenated ones)
    validIndustries: [
        'contractors-trades',
        'real-estate',
        'retail-ecommerce',
        'fitness',
        'healthcare',
        'legal',
        'photography',
        'restaurants',
        'roofing'
    ],
    // Quality settings for automated optimization
    imageQuality: {
        jpeg: { quality: 80, mozjpeg: true },
        png: { compressionLevel: 9 },
        webp: { quality: 75, smartSubsample: true },
        avif: { quality: 75 }
    }
};

async function distributeAssets() {
    console.log('🚀 Starting Asset Distribution Pipeline...');

    // 1. Ensure drop zone exists
    if (!fs.existsSync(CONFIG.dropZone)) {
        fs.mkdirSync(CONFIG.dropZone);
        console.log(`✨ Created drop zone at: ${CONFIG.dropZone}`);
        console.log('👉 Place your named images (e.g., "legal-hero-1.jpg") in that folder and run this script again.');
        return;
    }

    // 2. Find all images in the drop zone
    console.log(`🔍 Searching in: ${CONFIG.dropZone}`);

    // Use fs.readdirSync for reliability
    const allFiles = fs.readdirSync(CONFIG.dropZone);

    const rawImages = allFiles
        .filter(file => {
            const ext = path.extname(file).toLowerCase();
            return ['.jpg', '.jpeg', '.png', '.webp'].includes(ext);
        })
        .map(file => path.join(CONFIG.dropZone, file));

    if (rawImages.length === 0) {
        console.log('⚠️  No images found in _raw_assets. Nothing to do.');
        console.log('💡 Try: dir _raw_assets to see what files are there');
        return;
    }

    console.log(`📦 Found ${rawImages.length} images to process.`);

    let successCount = 0;
    let errorCount = 0;

    for (const imgPath of rawImages) {
        const filename = path.basename(imgPath);

        // 3. Parse filename: industry-section-desc.ext
        // Find the longest matching industry name from our valid list
        let industry = null;
        let restOfFilename = filename;

        for (const validIndustry of CONFIG.validIndustries) {
            if (filename.startsWith(validIndustry + '-')) {
                industry = validIndustry;
                restOfFilename = filename.substring(validIndustry.length + 1); // +1 for the hyphen
                break;
            }
        }

        if (!industry) {
            console.warn(`⚠️  Skipping ${filename}: Industry not recognized. Valid industries: ${CONFIG.validIndustries.join(', ')}`);
            continue;
        }

        // Extract extension from remaining filename
        const lastDotIndex = restOfFilename.lastIndexOf('.');
        if (lastDotIndex === -1) {
            console.warn(`⚠️  Skipping ${filename}: No file extension found`);
            continue;
        }

        const restOfName = restOfFilename.substring(0, lastDotIndex);
        const ext = restOfFilename.substring(lastDotIndex + 1).toLowerCase();

        // Validate extension
        if (!['jpg', 'jpeg', 'png', 'webp'].includes(ext)) {
            console.warn(`⚠️  Skipping ${filename}: Invalid extension '${ext}'. Supported: jpg, jpeg, png, webp`);
            continue;
        }

        // 4. Process the image with intelligent format selection
        const targetDir = path.join(CONFIG.industriesDir, industry, 'assets', 'images');

        // Verify industry exists
        if (fs.existsSync(path.join(CONFIG.industriesDir, industry))) {
            // Ensure target assets folder exists
            await fs.ensureDir(targetDir);

            try {
                // Analyze image content for intelligent processing
                const analysis = await analyzeImageContent(imgPath);
                console.log(`🔍 ${filename}: Detected as ${analysis.analysis.contentType} (${analysis.recommendations.reason})`);

                // Get intelligent format selection
                const formatsToUse = getIntelligentFormatsForDistribution(analysis);

                // Process each recommended format
                for (const format of formatsToUse) {
                    try {
                        const newFilename = `${industry}-${restOfName}.${format}`;
                        const targetPath = path.join(targetDir, newFilename);

                        console.log(`🔄 Processing: ${filename} -> ${industry}/.../${newFilename}`);

                        // Convert based on format and content type
                        await convertImageForDistribution(imgPath, targetPath, format, analysis);

                        successCount++;
                    } catch (formatError) {
                        console.warn(`⚠️  Failed to convert ${filename} to ${format}:`, formatError.message);
                        errorCount++;
                    }
                }

                // Optional: Delete original after successful processing
                // await fs.remove(imgPath);

            } catch (analysisError) {
                console.warn(`⚠️  Analysis failed for ${filename}, using fallback:`, analysisError.message);

                // Fallback to WebP conversion
                try {
                    const newFilename = `${industry}-${restOfName}.webp`;
                    const targetPath = path.join(targetDir, newFilename);

                    console.log(`🔄 Processing (fallback): ${filename} -> ${industry}/.../${newFilename}`);

                    await sharp(imgPath)
                        .webp(CONFIG.imageQuality.webp)
                        .toFile(targetPath);

                    successCount++;
                } catch (fallbackError) {
                    console.error(`❌ Failed to process ${filename} (fallback):`, fallbackError.message);
                    errorCount++;
                }
            }
        } else {
            console.warn(`⚠️  Skipping ${filename}: Industry "${industry}" not found.`);
        }
    }

    console.log(`\\n✅ Finished! Successfully distributed: ${successCount} | Errors: ${errorCount}`);
}

/**
 * Get intelligent format selection for distribution based on image analysis
 */
function getIntelligentFormatsForDistribution(analysis) {
    const { recommendations } = analysis;

    // For distribution, we want multiple formats for better browser support
    // Icons: SVG primary, WebP/AVIF fallback
    // Photos: JPEG primary, WebP/AVIF for modern browsers
    if (analysis.analysis.isIcon) {
        return ['svg', 'webp', 'avif'];
    } else {
        return ['jpeg', 'webp', 'avif'];
    }
}

/**
 * Convert image for distribution with appropriate format handling
 */
async function convertImageForDistribution(inputPath, outputPath, format, analysis) {
    const ext = path.extname(outputPath).toLowerCase();

    switch (format) {
        case 'svg':
            // SVG conversion only for PNG icons
            if (analysis.metadata.format === 'png' && analysis.analysis.isIcon) {
                const success = await convertPngToSvg(inputPath, outputPath);
                if (!success) {
                    throw new Error('SVG conversion failed');
                }
            } else {
                throw new Error('SVG conversion only supported for PNG icons');
            }
            break;

        case 'jpeg':
            await sharp(inputPath)
                .jpeg(CONFIG.imageQuality.jpeg)
                .toFile(outputPath);
            break;

        case 'webp':
            await sharp(inputPath)
                .webp(CONFIG.imageQuality.webp)
                .toFile(outputPath);
            break;

        case 'avif':
            await sharp(inputPath)
                .avif(CONFIG.imageQuality.avif)
                .toFile(outputPath);
            break;

        default:
            throw new Error(`Unsupported format: ${format}`);
    }
}

distributeAssets();
